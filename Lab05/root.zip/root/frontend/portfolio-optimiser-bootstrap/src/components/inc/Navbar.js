import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const navtextStyle = {
  fontFamily: 'OCR A Std, monospace',
  fontWeight: 600,// Apply the minimalist font here
};

function Navbar() {
  const navigate = useNavigate();
  const token = sessionStorage.getItem('token');
  const isAuthenticated = !!token; // Check if the user is authenticated

  const handleSignOut = async () => {
    try {
      // Make a request to the backend API endpoint for user logout
      const response = await fetch('http://172.21.148.171:8000/api-auth/logout/', {
        method: 'POST',
        headers: {
          'Authorization': `Token ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        sessionStorage.removeItem('token'); // Remove the token from local storage
        sessionStorage.removeItem('task_id'); // Remove the task_id from local storage
        sessionStorage.removeItem('play_id');
        navigate('/login'); // Redirect to the login page
      } else {
        console.error('Logout failed');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <nav className="navbar navbar-expand-lg" style={{ background: 'linear-gradient(to right, #0d47a1, #2196f3)', ...navtextStyle }}> {/* Add fixed-top class */}
      <div className="container-fluid">
        <Link to="/" className="navbar-brand">
          <img src="TechTitans_NavBar.png" alt="Logo" width="150" height="auto" />
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <Link to="/" className="nav-link active text-white">
                Home
              </Link>
            </li>
            {isAuthenticated ? (
              <>
                <li className="nav-item">
                  <Link to="/my-transactions" className="nav-link active text-white">
                    My Transactions
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/my-portfolio" className="nav-link active text-white">
                    My Portfolio
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/optimise" className="nav-link active text-white">
                    Optimise
                  </Link>
                </li>

                <li className="nav-item">
                  <Link to="/playground" className="nav-link active text-white">
                    Playground
                  </Link>
                </li>

                <li className="nav-item">
                  <Link to="/stocks" className="nav-link active text-white">
                    Stocks
                  </Link>
                </li>
                <li className="nav-item dropdown">
                  <a
                    className="nav-link dropdown-toggle text-white"
                    href="#"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Profile
                  </a>
                  <ul className="dropdown-menu">
                    <Link to="/my-profile" className="dropdown-item">
                      My Profile
                    </Link>
                    <a className="dropdown-item" onClick={handleSignOut}>
                      Sign Out
                    </a>
                  </ul>
                </li>
                <li className="nav-item">
                  <Link to="/forget-password" className="dropdown-item">
                  </Link>
                </li>
              </>
            ) : (
              <>
                <li className="nav-item">
                  <Link to="/stocks" className="nav-link active text-white">
                    Stocks
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/login" className="nav-link active text-white">
                    Login
                  </Link>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
