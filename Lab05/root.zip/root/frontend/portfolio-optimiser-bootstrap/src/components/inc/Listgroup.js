import React from 'react';

function Listgroup({ stockList, onStockClick }) {
  return (
    <div className="list-group">
      {stockList.map((stock) => (
        <button
          key={stock.id}
          type="button"
          className="list-group-item list-group-item-action"
          onClick={() => onStockClick(stock)}
        >
          {stock.name}
        </button>
      ))}
    </div>
  );
}

export default Listgroup;
