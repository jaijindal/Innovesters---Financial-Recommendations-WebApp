import React from 'react';
import Plot from 'react-plotly.js';

const StockModal = ({ show, onHide, stock, chartData, loading }) => {
  const modalDisplay = show ? 'block' : 'none';

  return (
    <div className="modal" style={{ display: modalDisplay }}>
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header" style={{ borderBottom: 'none' }}>
            <h5 className="modal-title">{loading ? 'Loading...' : `${stock.name} (${stock.symbol})`}</h5>
            <button type="button" className="btn-close" aria-label="Close" onClick={onHide}></button>
          </div>
          <div className="modal-body" style={{ borderBottom: 'none' }}>
            {loading ? (
              <div>Loading...</div>
            ) : (
              <>
                <p>Previous close: {stock.Previous_Close}</p>
                <p>Open: {stock.Open}</p>
                <p>Bid: {stock.Bid}</p>
                <p>Ask: {stock.Ask}</p>
                <p>Day's range: {stock.Days_Range}</p>
                <Plot
                  data={[
                    {
                      x: chartData.dates,
                      y: chartData.close_prices,
                      type: 'scatter',
                      mode: 'lines',
                      marker: {color: 'green'},
                    }
                  ]}
                  layout={{
                    width: 450, 
                    height: 400, 
                    title: stock.name,
                    xaxis: {
                      title: 'Date',
                    },
                    yaxis: {
                      title: 'Close Price',
                    },
                  }}
                />
                <div>
                  <h5>Recent news</h5>
                  {stock.news_articles_data.map((article) => (
                    <div key={article.index}>
                      <p>
                        <a href={article.href} target="_blank" rel="noopener noreferrer">
                        {article.headline}
                        </a>
                      </p>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
          <div className="modal-footer" style={{ borderTop: 'none' }}>
            <button type="button" className="btn btn-secondary" onClick={onHide}>
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StockModal;