import React, { useState } from 'react';

function Register() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleRegister = async (e) => {
    e.preventDefault();
    // Validation logic here
    if (password.length < 8) {
      setMessage('Password should be at least 8 characters long.');
      setTimeout(() => setMessage(null), 2500);
      return;
    } else if (password !== confirmPassword) {
      setMessage('Passwords do not match.');
      setTimeout(() => setMessage(null), 2500);
      return;
    }

    try {
      const response = await fetch('http://172.21.148.171:8000/api-auth/register/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: username,
          email: email,
          password1: password,
          password2: confirmPassword,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage('Registration successful!');
        // Optionally, redirect to login page after successful registration
        // window.location.href = '/login';
      } else {
        if (data.data.error.username) {
          setMessage(data.data.error.username[0]);
          setTimeout(() => setMessage(null), 2500);
        } else if (data.data.error.non_field_errors) {
            setMessage(data.data.error.non_field_errors[0]);
            setTimeout(() => setMessage(null), 2500);
        }
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Registration failed. Please try again later.');
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h1 className="card-title text-center">Register</h1>
              <form onSubmit={handleRegister}>
                <div className="mb-3">
                  <label htmlFor="username" className="form-label">
                    Username:
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">
                    Email:
                  </label>
                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="password" className="form-label">
                    Password:
                  </label>
                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="confirmPassword" className="form-label">
                    Confirm Password:
                  </label>
                  <input
                    type="password"
                    className="form-control"
                    id="confirmPassword"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                </div>
                <div className="d-grid gap-2">
                  <button type="submit" className="btn btn-primary">
                    Register
                  </button>
                </div>
              </form>
              <p className="text-center mt-3" style={{ color: message === 'Registration successful!' ? 'green' : 'red' }}>{message}</p>
              <p className="text-center mt-3">
                Already have an account? <a href="/login">Login here</a>.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Register;
