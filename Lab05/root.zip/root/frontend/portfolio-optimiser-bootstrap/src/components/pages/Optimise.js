import React, { useEffect, useState } from 'react';
import Plot from 'react-plotly.js';
import axios from 'axios';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

function Optimise() {
    const [isLoading, setIsLoading] = useState(false);
    const [chartData, setChartData] = useState(null);
    const [pieChartData, setPieChartData] = useState(null);
    const [lineChartData, setLineChartData] = useState(null);
    const [socket, setSocket] = useState(null);
    const [currentRiskTolerance, setCurrentRiskTolerance] = useState(null);
    
    const fetchTaskResult = (taskId) => {
        axios.get(`http://172.21.148.171:8000/api-stocks/task-results/${taskId}/`, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Token ${sessionStorage.getItem('token')}`
            }
        })
        .then(response => {
            const sharpeRatios = response.data.means.map((value, i) => (value / response.data.risks[i]));
                const data = [
                    {
                        x: response.data.risks,
                        y: response.data.means,
                        mode: 'markers',
                        marker: {
                            color: sharpeRatios,
                            colorscale: 'Viridis',
                            colorbar: {title: 'Sharpe Ratio'},
                        },
                        type: 'scatter',
                    },
                ];

                const layout = {
                    xaxis: { title: 'Expected Volatility' },
                    yaxis: { title: 'Expected Return' },
                    width: 600,
                    height: 500,
                    autosize: false
                };

                setChartData({data, layout});

                const pieData = [
                    {
                        values: response.data.portfolio_weights,
                        labels: response.data.stocks,
                        type: 'pie',
                        textinfo: 'label+percent',
                        textposition: 'inside',
                        automargin: true
                    }
                ];

                const pieLayout = {
                    height: 400,
                    width: 500,
                    title: 'Optimal Portfolio Allocation',
                    showlegend: false
                };

                setPieChartData({data: pieData, layout: pieLayout});

                const lineData = Object.keys(response.data.dataset[0]).filter(key => key !== 'Date').map(stock => {
                    const yValues = response.data.dataset.map(row => row[stock]);
                    const xValues = response.data.dataset.map(row => new Date(row['Date']));
                    return {
                        x: xValues,
                        y: yValues,
                        mode: 'lines',
                        name: stock
                    };
                });

                const lineLayout = {
                    xaxis: { title: 'Time' },
                    yaxis: { title: 'Stock Price' },
                    width: 600,
                    height: 500,
                    autosize: false
                };

                setLineChartData({data: lineData, layout: lineLayout});
                setIsLoading(false);
            });
        }

    useEffect(() => {
        axios.get('http://172.21.148.171:8000/api-auth/risk/', {
            headers: {
                'Authorization': `Token ${sessionStorage.getItem('token')}`,
            },
        })
        .then((response) => {
            setCurrentRiskTolerance(response.data.risk_choices[response.data.risk]);
        })
        .catch((error) => {
            console.error('Error:', error);
        });
        const storedTaskId = sessionStorage.getItem('task_id');
        if (storedTaskId) {
            const ws = new WebSocket('ws://172.21.148.171:8001/ws/task-status/');
    
            ws.onopen = () => {
                console.log('WebSocket connection opened');
                ws.send(JSON.stringify({
                    'task_id': storedTaskId
                }));
            };
    
            ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                setIsLoading(true);
                if (data.status === 'SUCCESS') {
                    setIsLoading(false);
                    fetchTaskResult(storedTaskId);
                }
            };
    
            ws.onclose = () => {
                console.log('WebSocket connection closed');
                setIsLoading(false);
            };
    
            setSocket(ws);
    
            return () => {
                ws.close();
            };
        }
    }, []);

    const handleClick = () => {
        if (sessionStorage.getItem('task_id')) {
            sessionStorage.removeItem('task_id');
        }
        axios.get('http://172.21.148.171:8000/api-stocks/optimal/', {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Token ${sessionStorage.getItem('token')}`
            }
        })
        .then(response => {     
            const taskId = response.data.task_id;
            sessionStorage.setItem('task_id', taskId);
            const ws = new WebSocket('ws://172.21.148.171:8001/ws/task-status/');

            ws.onopen = () => {
                console.log('WebSocket connection opened');
                setIsLoading(true);
                ws.send(JSON.stringify({
                    'task_id': taskId
                }));
            };

            ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                if (data.status === 'SUCCESS') {
                    alert('Portfolio Optimised!');
                    setIsLoading(false);
                    fetchTaskResult(taskId);
                }
            };

            ws.onclose = () => {
                console.log('WebSocket connection closed');
                setIsLoading(false);
            };

            setSocket(ws);

            return () => {
                ws.close();
            };
        });
    }

    if (isLoading) {
        return (
        <div className="container mt-4 card-body">
            <div class="text-center">
                <h4>Optimizing to perfection...</h4>
                <p>P.S go grab a coffee or something. We'll be done by the time you're back ;)</p>
                <img src="CoffeeCat.gif"/>
                
            </div>
        </div>
        );
    }

    const sliderContainerStyle = {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      width: '100%', // Set the width of the container to 100%
    };

    const sliderSettings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      prevArrow: (
        <div
            className="custom-arrow custom-arrow-left"
            onClick={() => Slider.slickPrev()}
        >
            {'<'}
        </div>
      ),
      nextArrow: (
          <div
              className="custom-arrow custom-arrow-right"
              onClick={() => Slider.slickNext()}
          >
              {'>'}
          </div>
      ),
    };

    return (
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', flexWrap: 'wrap', padding: '20px', margin: '0 auto' }}>
          {/* Risk Tolerance and Generate Optimized Portfolio button */}
          <div style={{ margin: '10px', width: '100%' }}>
            <div className="card border-0">
                <div className="card-body text-center">
                <button type="button" className="btn btn-success" onClick={handleClick}>
                    Generate Optimized Portfolio
                </button>
                <p></p>
                <p>Current Risk Tolerance: {currentRiskTolerance}</p>
                </div>
            </div>
            </div>
        
          {/* Two-column layout */}
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap', width: '100%' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: '100%'}}>
              <div style={{width: '80%' }}>
                <div className="card">
                  <div className="card-body">
                    <h5 className="card-title text-center" mb-2>Your Optimal Portfolio</h5>
                    {pieChartData && (
                      <div>
                      <div style={{ display: 'flex', flexDirection: 'row' }}>
                        <div style={{ flexBasis: '60%' }}>
                          <Plot data={pieChartData.data} layout={pieChartData.layout} />
                        </div>
                        <div style={{ flexBasis: '40%', marginLeft: '20px' }}>
                          <p className="card-text">
                            <strong>Optimal Asset Allocation:</strong> The pie chart clearly illustrates how your investment portfolio should be allocated for optimal risk-adjusted returns. It shows the percentage of your portfolio that should be invested in each asset to maximize your Sharpe ratio, which is a measure of risk-adjusted return.
                          </p>
                          <p className="card-text">
                            <strong>Balanced Risk and Return:</strong> The most optimized portfolio, as indicated by the Sharpe ratio, strikes a balance between risk and return. The pie chart shows that you don't need to put all your investments in a single asset or asset class to achieve the best risk-adjusted returns. Instead, it recommends a diversified approach.
                          </p>
                          <p className="card-text">
                            <strong>Risk Management:</strong> The allocation in the pie chart is designed to minimize portfolio risk while maximizing return potential. It is a crucial tool for managing risk, as it helps you diversify your investments and avoid putting all your eggs in one basket.
                          </p>
                        </div>
                      </div>
                    </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
      
            <div style={{ width: '100%'}}>
            <h5 className="card-title mt-5 mb-3 text-center">The Process</h5>
            <div style={sliderContainerStyle}>
            <Slider {...sliderSettings} style={{ width: '80%' }} >
            {/* Chart 1 */}
            <div>
              <div className="card mt-2">
                <div className="card-body" >
                  {lineChartData && (
                    <div style={{ display: 'flex', flexDirection: 'row' }}>
                      <div style={{ flexBasis: '60%' }}>
                        <Plot data={lineChartData.data} layout={lineChartData.layout} />
                      </div>
                      <div style={{ flexBasis: '40%', marginLeft: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'center'}}>
                        <p className="card-text">
                          <strong>Historical Stock Prices:</strong> This graph shows historical stock prices for the stocks you're interested in. It's essential for your decision-making process as you can assess past price trends to make informed investment decisions.
                        </p>
                        <p className="card-text mt-4">
                          <strong>How You Can Use It:</strong> Analyze the historical performance of individual stocks you're considering. It helps you understand how these stocks have behaved over time, which is crucial for evaluating potential capital gains or losses.
                        </p>
                      </div>
                      </div>
                  )}
                </div>
              </div>
            </div>
            {/* Chart 2 */}
            <div>
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Chart Data</h5>
                  {chartData && (
                    <div style={{ display: 'flex', flexDirection: 'row' }}>
                      <div style={{ flexBasis: '60%' }}>
                        <Plot data={chartData.data} layout={chartData.layout} />
                      </div>
                      <div style={{ flexBasis: '40%', marginLeft: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                        <p className="card-text">
                          <strong>Scatter Plot:</strong> The scatter plot illustrates the trade-off between risk and return in different portfolio allocations. It's highly relevant to you because it helps you tailor your investments to your unique risk tolerance and return expectations.
                        </p>  
                        <p className="card-text mt-4">
                          <strong>How You Can Use It:</strong> Identify portfolios that strike the right balance between risk and return. This visual representation simplifies the process of constructing portfolios that align with your investment goals.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </Slider>
          </div>
          </div>
          </div>
        </div>
      );
}

export default Optimise;