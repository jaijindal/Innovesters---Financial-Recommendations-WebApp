import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '/home/VMuser/Desktop/root/frontend/portfolio-optimiser-bootstrap/src/error-message.css';

function Login() {
  const [inputs, setInputs] = useState({ username: '', password: '' });
  const [token, setToken] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setInputs((prevInputs) => ({ ...prevInputs, [name]: value }));
  };

  const handleRegister  = () => {
    // 👇️ navigate to /contacts
    navigate('/register');
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setErrorMessage('');
    try {
      const response = await fetch('http://172.21.148.171:8000/api-auth/login/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: inputs.username,
          password: inputs.password,
        }),
      });
  
      if (response.ok) {
        const data = await response.json();
        setToken(data.token);
        sessionStorage.setItem('token', data.token);
        console.log('Token:', data.token);
        navigate('/');
      } else {
        // Handle login failure here
        const data = await response.json();
        setErrorMessage(data.error);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  return (
    
    <div className="container" style={{ marginTop: '70px' }}>
      <div className="row justify-content-center">
        {/* Left Column (Welcome Text) */}
        <div className ="row">
          <div className="col-md-6">
            <div style={{padding: '100px 0px'}}>
            <img src= "TechTitansText_half.png"/>
            <p/><p>
              Why waste time figuring what stocks to buy, when AI can do it better? Optimize your portfolio now!
            </p>
            </div>
          </div>
          <div className="col-md-6">
            <div className="card card-body">
              <h1 className="card-title text-center">Login</h1>
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  {/* <label htmlFor="username" className="form-label">
                    Username:
                  </label> */}
                  <input
                    type="text"
                    className="form-control"
                    placeholder='Username'
                    id="username"
                    name="username"
                    value={inputs.username}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  {/* <label htmlFor="password" className="form-label">
                    Password:
                  </label> */}
                  <input
                    type="password"
                    className="form-control"
                    placeholder='Password'
                    id="password"
                    name="password"
                    value={inputs.password}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="d-grid gap-2">
                  {errorMessage && <div className="error-message">{errorMessage}</div>}
                  <button type="submit" className="btn btn-primary">
                    Login
                  </button>
                  <p className="text-center mt-3"> <a href="/forget-password">Forgotten Password?</a></p>
                </div>
              </form>
              <div className="row justify-content-center">
                <button style={{ width: '200px' }} className="btn btn-sm btn-secondary" appearance="primary" onClick={handleRegister}>
                  Create a new account
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
