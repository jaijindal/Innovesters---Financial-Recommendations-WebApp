import React, { useState, useEffect } from 'react';
import stockList from '/home/VMuser/Desktop/root/frontend/portfolio-optimiser-bootstrap/src/components/inc/Stocklist.js';

const TransactionLog = () => {
  const [transactions, setTransactions] = useState([]);
  const [editingTransactionId, setEditingTransactionId] = useState(null);
  const [message, setMessage] = useState(null);
  const [newTransaction, setNewTransaction] = useState({
    stock: '',
    transaction_type: '',
    quantity: '',
    price: '',
    timestamp: '',
  });

  const startEditing = (id) => {
    setEditingTransactionId(id);
    const transactionToEdit = transactions.find((transaction) => transaction.id === id);
  };

  const editTransaction = (editedTransaction) => {
    fetch(`http://172.21.148.171:8000/api-trans/transaction/`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Token ${sessionStorage.getItem('token')}`,
      },
      body: JSON.stringify({
        id: editedTransaction.id,
        ...editedTransaction,
      }),
    })
      .then(response => {
        if (!response.ok) {
          setMessage('Failed to edit transaction. Please try again.');
          setTimeout(() => setMessage(null), 2500);
        }
        return response;
      })
      .then(() => {
        fetchTransactions();
        setEditingTransactionId(null);
      })
      .catch(error => {
        setMessage(error.message);
        setTimeout(() => setMessage(null), 2500);
      });
  };

  const cancelEditing = () => {
    setEditingTransactionId(null);
  };

  const fetchTransactions = () => {
    fetch('http://172.21.148.171:8000/api-trans/transaction/', {
      headers: {
        'Authorization': `Token ${sessionStorage.getItem('token')}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        const sortedData = data.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        setTransactions(sortedData);
      });
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  const handleInputChange = (event, field) => {
    const value = field === 'transaction_type' ? event.target.value.toUpperCase() : event.target.value;
    setNewTransaction({ ...newTransaction, [field]: value });
  };

  const logTransaction = () => {
    if (!newTransaction.stock || !newTransaction.transaction_type || !newTransaction.quantity || !newTransaction.price) {
      setMessage('Please enter values for Stock, Transaction Type, Quantity, and Price.');
      setTimeout(() => setMessage(null), 2500);
      return;
    }
  
    // If all fields are filled, proceed with the fetch request
    fetch('http://172.21.148.171:8000/api-trans/transaction/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Token ${sessionStorage.getItem('token')}`,
      },
      body: JSON.stringify(newTransaction),
    })
      .then(response => {
        if (!response.ok) {
          setMessage('Failed to log transaction. Please try again.');
          setTimeout(() => setMessage(null), 2500);
        }
        return response;
      })
      .then(() => {
        fetchTransactions();
        setNewTransaction({
          stock: '',
          transaction_type: '',
          quantity: '',
          price: '',
          timestamp: '',
        });
      });
  };

  const deleteTransaction = async (id) => {
    const confirmDelete = window.confirm('Are you sure you want to delete this transaction?');

    if (confirmDelete) {
      try {
        const response = await fetch('http://172.21.148.171:8000/api-trans/transaction/', {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Token ${sessionStorage.getItem('token')}`,
          },
          body: JSON.stringify({ id: id }),
        });

        if (response.ok) {
          // Successfully deleted, update the transactions list
          fetchTransactions();
        } else {
          // Handle delete failure here
          setMessage('Delete failed');
          setTimeout(() => setMessage(null), 2500);
        }
      } catch (error) {
        // Handle network errors or other exceptions here
        console.error('Error:', error);
      }
    }
  };



  const EditTransaction = ({ transaction, onEdit, onCancel }) => {
    const [editedTransaction, setEditedTransaction] = useState({ ...transaction });

    const handleInputChange = (event, field) => {
      setEditedTransaction({ ...editedTransaction, [field]: event.target.value });
    };  

    const saveEdit = () => {
      onEdit(editedTransaction);
    };
    return (
      <tr>
        <td>
          <select
            value={editedTransaction.stock}
            onChange={(e) => handleInputChange(e, 'stock')}
          >
            <option value="">Select Stock</option>
            {stockList.map((stock) => (
              <option key={stock.id} value={stock.symbol}>
                {stock.symbol}
              </option>
            ))}
          </select>
        </td>
        <td>
          <select
            value={editedTransaction.transaction_type}
            onChange={(e) => handleInputChange(e, 'transaction_type')}
          >
            <option value="BUY">BUY</option>
            <option value="SELL">SELL</option>
          </select>
        </td>
        <td>
          <input
            type="number"
            value={editedTransaction.quantity}
            onChange={(e) => handleInputChange(e, 'quantity')}
          />
        </td>
        <td>
          <input
            type="number"
            value={editedTransaction.price}
            onChange={(e) => handleInputChange(e, 'price')}
          />
        </td>
        <td/>
        <td>
          <button class ='btn btn-sm btn-success' onClick={saveEdit}>Save</button>{' '}
          <button class ='btn btn-sm btn-outline-success' onClick={onCancel}>Cancel</button>
        </td>
      </tr>
    );
  };

  return (
    <div className="container">
      <div className='card mt-4' style={{border: 'none' }}>
        <div className='card-body text-center'>
          <h2>Transaction History</h2>
        </div>
      </div>
      <div className="card" style={{border: 'none' }}>
      <h4>Add New Transaction</h4>
        <div className='card-body text-center'>
          <form>
            <div className="row g-3">
              <div className="col-sm">
                <label className="form-label"><b>Stock</b></label>
                <select
                  className="form-select"
                  value={newTransaction.stock}
                  onChange={(e) => handleInputChange(e, 'stock')}
                >
                  <option value="">Stock</option>
                  {stockList.map((stock) => (
                    <option key={stock.id} value={stock.symbol}>
                      {stock.symbol}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-sm">
                <label className="form-label"><b>Transaction Type</b></label>
                <select
                  className="form-select"
                  value={newTransaction.transaction_type}
                  onChange={(e) => handleInputChange(e, 'transaction_type')}
                >
                  <option value="">Select Transaction Type</option>
                  <option value="BUY">BUY</option>
                  <option value="SELL">SELL</option>
                </select>
              </div>
              <div className="col-sm">
                <label className="form-label"><b>Quantity</b></label>
                <input
                  type="number"
                  className="form-control"
                  value={newTransaction.quantity}
                  onChange={(e) => handleInputChange(e, 'quantity')}
                />
              </div>
              <div className="col-sm">
                <label className="form-label"><b>Price</b></label>
                <input
                  type="number"
                  className="form-control"
                  value={newTransaction.price}
                  onChange={(e) => handleInputChange(e, 'price')}
                />
              </div>
                <div>
                  <button type="button" class="btn btn-success" onClick={logTransaction}>
                  Log Transaction
                </button>
              </div>
            </div>
          </form>
        </div>
      </div><p/>
      {message && <div className="alert alert-danger text-center small">{message}</div>}
      <div className='card-body' >
        <h3>Transaction List</h3>
        <table className="table">
          <thead>
            <tr>
              <th>Stock</th>
              <th>Transaction Type</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Timestamp</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction, index) => (
              editingTransactionId === transaction.id ? (
                <EditTransaction
                  key={transaction.id}
                  transaction={transaction}
                  onEdit={editTransaction}
                  onCancel={cancelEditing}
                />
              ) : (
                <tr key={transaction.id}>
                  <td>{transaction.stock}</td>
                  <td>{transaction.transaction_type}</td>
                  <td>{transaction.quantity}</td>
                  <td>{transaction.price}</td>
                  <td>{transaction.timestamp}</td>
                  <td>
                    <button type="button" className="btn btn-danger btn-sm me-2" onClick={() => deleteTransaction(transaction.id)} style={{color: 'white' }}>
                      Delete
                    </button>
                    <button type="button" className="btn btn-warning btn-sm" onClick={() => startEditing(transaction.id)} style={{color: 'black' }}>
                      Edit
                    </button>
                  </td>
                </tr>
              )
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TransactionLog;