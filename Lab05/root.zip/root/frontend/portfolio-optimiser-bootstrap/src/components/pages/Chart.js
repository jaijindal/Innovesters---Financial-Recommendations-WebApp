import React, { useEffect, useRef, useState } from 'react';

function Chart() {
  const chartRef = useRef(null);
  const [chartData, setChartData] = useState(null);

  useEffect(() => {
    // Fetch data from the backend
    fetch('http://localhost:8000/api-stocks/yahoo/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ ticker: 'AAPL' }), // Replace with your desired ticker symbol
    })
      .then((response) => response.json())
      .then((data) => {
        setChartData(data);

        const ctx = chartRef.current.getContext('2d');
        new Chart(ctx, {
          type: 'line',
          data: {
            labels: data.dates,
            datasets: [
              {
                label: 'Close Prices',
                data: data.close_prices,
                fill: false,
                borderColor: 'rgb(75, 192, 192)',
                tension: 0.1,
              },
            ],
          },
        });
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  }, []);

  return (
    <div>
      <canvas id="myChart" ref={chartRef}></canvas>
    </div>
  );
}

export default Chart;
