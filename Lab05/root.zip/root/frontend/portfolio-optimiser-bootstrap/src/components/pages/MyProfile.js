import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function Profile() {
  const [newRiskTolerance, setRisk] = useState('');
  const [newInvestmentGoals, setGoal] = useState('');
  const [newPassword, setPass] = useState('');
  const [currentPassword, setCurrentPass] = useState('');
  const [confirmPassword, setConfirmPass] = useState('');
  const [message, setMessage] = useState('');
  const [isEditingPassword, setIsEditingPassword] = useState(false);
  const [currentRiskTolerance, setCurrentRiskTolerance] = useState('');
  const [riskToleranceOptions, setRiskToleranceOptions] = useState([]);
  const [currentInvestmentGoals, setCurrentInvestmentGoals] = useState('');
  const [investmentGoalsOptions, setInvestmentGoalsOptions] = useState([]);
  const [newEmail, setNewEmail] = useState('');
  const [email, setEmail] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [username, setUsername] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [image, setImage] = useState(null);

  useEffect(() => {
    // Fetch risk tolerance options and current values when the component mounts
    fetch('http://172.21.148.171:8000/api-auth/risk/', {
      method: 'GET',
      headers: {
        'Authorization': `Token ${sessionStorage.getItem('token')}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRiskToleranceOptions(data.risk_choices);
        setCurrentRiskTolerance(data.risk_choices[data.risk]);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
      
    // Fetch investment goals and current value from the backend
    fetch('http://172.21.148.171:8000/api-auth/investment/', {
      method: 'GET',
      headers: {
        'Authorization': `Token ${sessionStorage.getItem('token')}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setInvestmentGoalsOptions(data.investment_choices);
        setCurrentInvestmentGoals(data.investment_choices[data.investment]);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
      fetch('http://172.21.148.171:8000/api-auth/email-change/', {
        method: 'GET',
        headers: {
          'Authorization': `Token ${sessionStorage.getItem('token')}`,
        },
      })
        .then((response) => response.json())
        .then((data) => {
          setEmail(data.email);
        })
        .catch((error) => {
          console.error('Error:', error);
        });
        fetch('http://172.21.148.171:8000/api-auth/user-change/', {
          method: 'GET',
          headers: {
            'Authorization': `Token ${sessionStorage.getItem('token')}`,
          },
        })
          .then((response) => response.json())
          .then((data) => {
            setUsername(data.username);
          })
          .catch((error) => {
            console.error('Error:', error);
          });
          axios.get('http://172.21.148.171:8000/api-auth/image/', {
              headers: {
                  'Authorization': `Token ${sessionStorage.getItem('token')}`
              }
          })
            .then(response => {
                setImage(`http://172.21.148.171:8000/api-auth${response.data.image}`);
            });
  }, []);
    

  const updateRisk = (e) => {
    e.preventDefault();

    // Find the key that corresponds to newRiskTolerance
    const riskKey = Object.keys(riskToleranceOptions).find(key => riskToleranceOptions[key] === newRiskTolerance);

    // Prepare the data to send to the API
    const data = {
      risk: riskKey,
    };

    // Make a POST request to update the risk data
    fetch('http://172.21.148.171:8000/api-auth/risk/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Token ${sessionStorage.getItem('token')}`,
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        if (response.ok) {
          setMessage('Successfully updated risk tolerance');
          setTimeout(() => setMessage(''), 2500);
          setIsSuccess(true);
          setCurrentRiskTolerance(newRiskTolerance); // Update the current risk data
          sessionStorage.removeItem('task_id');
          sessionStorage.removeItem('play_id');
        } else {
          setMessage('Failed to update risk tolerance');
          setTimeout(() => setMessage(''), 2500);
          setIsSuccess(false);
        }
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  const updateGoal = (e) => {
    e.preventDefault();

    const goalKey = Object.keys(investmentGoalsOptions).find(key => investmentGoalsOptions[key] === newInvestmentGoals);

    // Prepare the data to send to the API
    const data = {
      investment: goalKey,
    };

    // Make a POST request to update the risk data
    fetch('http://172.21.148.171:8000/api-auth/investment/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Token ${sessionStorage.getItem('token')}`,
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        if (response.ok) {
          setMessage('Successfully updated investment goals');
          setTimeout(() => setMessage(''), 2500);
          setIsSuccess(true);
          setCurrentInvestmentGoals(newInvestmentGoals); // Update the current risk data
        } else {
          setMessage('Failed to update investment goals');
          setTimeout(() => setMessage(''), 2500);
          setIsSuccess(false);
        }
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  const updateEmail = (e) => {
    e.preventDefault();
  
    // Prepare the data to send to the API
    const data = {
      email: newEmail,
    };
  
    // Make a POST request to the email update API endpoint
    fetch('http://172.21.148.171:8000/api-auth/email-change/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Token ${sessionStorage.getItem('token')}`,
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        if (response.ok) {
          setMessage('Successfully updated email');
          setTimeout(() => setMessage(''), 2500);
          setEmail(newEmail);
          setNewEmail('');
          setIsSuccess(true);
        } else {
          setMessage('Failed to update email');
          setTimeout(() => setMessage(''), 2500);
          setIsSuccess(false);
        }
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  const updateUsername = (e) => {
    e.preventDefault();
  
    // Prepare the data to send to the API
    const data = {
      username: newUsername,
    };
  
    // Make a POST request to the username update API endpoint
    fetch('http://172.21.148.171:8000/api-auth/user-change/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Token ${sessionStorage.getItem('token')}`,
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        if (response.ok) {
          setMessage('Successfully updated username');
          setTimeout(() => setMessage(''), 2500);
          setUsername(newUsername);
          setNewUsername('');
          setIsSuccess(true);
        } else {
          setMessage('Failed to update username');
          setTimeout(() => setMessage(''), 2500);
          setIsSuccess(false);
        }
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  const handleEditPassword = () => {
    // Toggle the editing mode for password
    setIsEditingPassword(!isEditingPassword);
  };

  const handleImageUpload = event => {
    const formData = new FormData();
    formData.append('image', event.target.files[0]);

    axios.post('http://172.21.148.171:8000/api-auth/image/', formData, {
        headers: {
            'Authorization': `Token ${sessionStorage.getItem('token')}`
        }
    })
        .then(response => {
          setImage(`http://172.21.148.171:8000/api-auth${response.data.image}`);
        });
};

  const updatePassword = (e) => {
    e.preventDefault();
    if (newPassword.length < 8) {
      setMessage('Password must contain at least 8 characters');
      setTimeout(() => setMessage(''), 2500);
      setIsSuccess(false);
    } else if (newPassword !== confirmPassword) {
      setMessage('New Password and Confirm Password must match');
      setTimeout(() => setMessage(''), 2500);
      setIsSuccess(false);
    } else {
      // Prepare the data to send to the API
      const data = {
        current_password: currentPassword,
        new_password: newPassword,
        confirm_password: confirmPassword,
      };

      // Make a POST request to the password change API endpoint
      fetch('http://172.21.148.171:8000/api-auth/password-change/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Token ${sessionStorage.getItem('token')}`,
        },
        body: JSON.stringify(data),
      })
        .then((response) => {
          if (response.ok) {
            setMessage('Successfully updated password');
            setTimeout(() => setMessage(''), 2500);
            setPass('');
            setCurrentPass('');
            setConfirmPass('');
            setIsEditingPassword(false);
            setIsSuccess(true);
          } else {
            setMessage('Failed to update password. Please check your current password.');
            setTimeout(() => setMessage(''), 2500);
            setIsSuccess(false);
          }
        })
        .catch((error) => {
          console.error('Error:', error);
        });
    }
  };

  return (
    <body>
      <div>
        <div className="container">
          <div className='card mt-4 border-0'>
            <div className='card-body text-center'>
              <h2>Profile Information</h2>
            </div>
          </div>
          <div className="d-flex align-items-center">
            <img src={image} alt="Profile" style={{ width: "50px", height: "50px", borderRadius: "10%", marginRight: "10px" }} />
            <label htmlFor="profilePicture" className="btn btn-sm btn-dark">
              Add Profile Picture
              <input
                type="file"
                id="profilePicture"
                className="visually-hidden"
                onChange={handleImageUpload}
              />
            </label>
          </div>
          <p>
            <b>Risk Tolerance Level:</b> {currentRiskTolerance}
          </p>{' '}
          <form onSubmit={updateRisk} id="riskToleranceForm" className="edit-form">
            <select
              value={newRiskTolerance}
              onChange={(e) => setRisk(e.target.value)}
              required
            >
            <option value="">Select Risk Tolerance</option>
            {Object.values(riskToleranceOptions).map((option, index) => (
              <option key={index} value={option}>
                {option}
              </option>
            ))}
          </select>{' '}
          <button type="submit" className="btn btn-dark btn-sm">Update</button>
        </form><p/>
        <p>
          <b>Investment Goals:</b> {currentInvestmentGoals}
        </p>
        <form onSubmit={updateGoal} id="investmentGoalsForm" className="edit-form">
          <select
            value={newInvestmentGoals}
            onChange={(e) => setGoal(e.target.value)}
            required
          >
            <option value="">Select Investment Goals</option>
            {Object.values(investmentGoalsOptions).map((option, index) => (
              <option key={index} value={option}>
                {option}
              </option>
            ))}
          </select>{' '}
          <button type="submit" className="btn btn-dark btn-sm">Update</button>
        </form><p/><p/>
        <p>
            <b>Current Email:</b> {email}
        </p>
        <form onSubmit={updateEmail} id="emailForm" className="edit-form">
          <input
            type="email"
            value={newEmail}
            placeholder="New Email"
            onChange={(e) => setNewEmail(e.target.value)}
            required
          />{' '}
          <button type="submit" className="btn btn-dark btn-sm">Update Email</button>
        </form><p/><p/>
        <p>
            <b>Current Username:</b> {username}
        </p>
        <form onSubmit={updateUsername} id="usernameForm" className="edit-form">
          <input
            type="text"
            value={newUsername}
            placeholder="New Username"
            onChange={(e) => setNewUsername(e.target.value)}
            required
          />{' '}
          <button type="submit" className="btn btn-dark btn-sm">Update Username</button>
        </form><p/><p/>
        <p>
          <div>
          <b>Change Password</b> 
          <span id="password"></span>{' '}
          <a/><button onClick={handleEditPassword} className="btn btn-dark btn-sm">Edit / Close</button>
          </div>
          
          {isEditingPassword ? (
            <div>

              <form onSubmit={updatePassword} className="edit-form">
                <div className='form-group'>
                <input
                  type="password"
                  value={currentPassword}
                  placeholder="Current Password"
                  onChange={(e) => setCurrentPass(e.target.value)}
                  required
                />
                </div>
                <div className='form-group'>
                <input
                  type="password"
                  value={newPassword}
                  placeholder="New Password"
                  onChange={(e) => setPass(e.target.value)}
                  required
                />
                </div>
                <div className='form-group'>

                <input
                  type="password"
                  value={confirmPassword}
                  placeholder="Confirm Password"
                  onChange={(e) => setConfirmPass(e.target.value)}
                  required
                />
                </div>
                <button type="submit" className="btn btn-dark btn-sm">Update</button>
              </form>
            </div>
          ) :null}
        </p>
        <p style={{ color: isSuccess ? 'green' : 'red' }}>{message}</p>
        </div>
      </div>
    </body>
  );
}

 



  