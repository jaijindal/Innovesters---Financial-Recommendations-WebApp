import React, { useEffect, useRef, useState } from 'react';
import { CSSTransition } from 'react-transition-group';
import { Chart, LineController, LinearScale, TimeScale, PointElement, LineElement } from 'chart.js';
import { dateFnsAdapter } from 'chartjs-adapter-date-fns';
import '/home/VMuser/Desktop/root/frontend/portfolio-optimiser-bootstrap/src/Home.css';

const API_URL = 'http://172.21.148.171:8000/api-stocks/yahoo-chart/';

Chart.register(LineController, LinearScale, TimeScale, PointElement, LineElement);

export default function Home() {
    const chartRef = useRef(null);
    const myChartRef = useRef(null);
    const [isTransitioning, setIsTransitioning] = useState(false);
    const [ticker, setTicker] = useState('AAPL');
    const tickers = ['AAPL', 'GOOG', 'MSFT', 'AMZN'];

    const updateTicker = () => {
        setTicker(tickers[getNewTickerIndex(tickers.indexOf(ticker), 'next')]);
        setIsTransitioning(false);
    };

    const getNewTickerIndex = (currentIndex, direction) => {
        return direction === 'next' 
            ? (currentIndex + 1) % tickers.length 
            : currentIndex === 0 ? tickers.length - 1 : currentIndex - 1;
    };

    const updateTickerToPrevious = () => setTicker(tickers[getNewTickerIndex(tickers.indexOf(ticker), 'prev')]);
    const updateTickerToNext = () => setTicker(tickers[getNewTickerIndex(tickers.indexOf(ticker), 'next')]);

    const createChart = (data) => {
        if (myChartRef.current) {
            myChartRef.current.destroy();
        }
        myChartRef.current = new Chart(chartRef.current, {
            type: 'line',
            data: {
                labels: data.dates,
                datasets: [{
                    label: 'Close Prices',
                    data: data.close_prices,
                    fill: false,
                    borderColor: 'white',
                    tension: 0.05
                }]
            },
            options: {
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        enabled: false
                    }
                },
                elements: {
                    point:{
                        radius: 0
                    }
                },
                scales: {
                    x: {
                        type: 'time',
                        display: true,
                        title: {
                            display: true,
                            text: 'Dates',
                            color: 'white',
                        },
                        ticks: {
                            color: 'white', // set color for x-axis ticks
                        },
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        title: {
                            display: true,
                            text: 'Close Prices',
                            color: 'white',
                        },
                        ticks: {
                            color: 'white', // set color for x-axis ticks
                          }
                    }
                }
            }
        });
    };

    const fetchData = async () => {
        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ ticker: ticker }),
            });
            const data = await response.json();
            if (myChartRef.current) {
                myChartRef.current.data.labels = data.dates;
                myChartRef.current.data.datasets[0].data = data.close_prices;
                myChartRef.current.update();
            } else {
                createChart(data);
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    useEffect(() => {
        const intervalId = setInterval(() => {
            setIsTransitioning(true);
        }, 3000);

        fetchData();

        return () => clearInterval(intervalId);
    }, [isTransitioning, ticker, tickers]);

    return (
        <div className="home-container card-body" style={{ background: 'linear-gradient(to right, #0d47a1, #2196f3)' }}>
                <h2 style={{ color: 'white' }}>Welcome to Innovesters! </h2>
                <p/>
            <div className="ticker-controls">
                <button className="btn btn-outline-light" style={{ color: 'white' }} onClick={updateTickerToPrevious}>&lt;</button>
                <div class="container-fluid">
                    <CSSTransition
                    in={!isTransitioning}
                    timeout={300}
                    classNames="fade"
                    unmountOnExit
                    onExited={updateTicker}
                    >
                    <h4 style={{ color: 'white' }}>{ticker}</h4>
                    </CSSTransition>
                </div>
                <button className="btn btn-outline-light" style={{ color: 'white' }} onClick={updateTickerToNext}>&gt;</button>
            </div>
            <div className="chart-container">
                <canvas id="myChart" ref={chartRef} ></canvas>
            </div>
        </div>
    );
}