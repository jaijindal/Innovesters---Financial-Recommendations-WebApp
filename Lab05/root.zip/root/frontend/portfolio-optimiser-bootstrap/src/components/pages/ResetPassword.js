import React, { useState } from 'react';
import axios from 'axios';
import { Navigate, useNavigate } from 'react-router-dom';

function ResetPassword() {
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [message, setMessage] = useState(''); // Add this line
    const navigate = useNavigate();

    const handleSubmit = async (event) => {
        event.preventDefault();

        if (password.length<8) {
            setMessage('Password should be at least 8 characters long.'); // Change this line
            setTimeout(() => setMessage(null), 2500);
            return;
        }

        if (password !== confirmPassword) {
            setMessage('Passwords do not match'); // Change this line
            setTimeout(() => setMessage(null), 2500);
            return;
        }

        const urlParams = new URLSearchParams(window.location.search);
        const token = urlParams.get('token');
        const uid = urlParams.get('uid');

        try {
            const response = await axios.post('http://172.21.148.171:8000/api-auth/reset-password/', {
                uid,
                token,
                new_password: password,
            });

            if (response.status === 200) {
                setMessage('Password reset successful'); // Change this line
                setTimeout(() => setMessage(null), 2500);
                navigate('/login');
            } else {
                setMessage('Password reset failed'); // Change this line
                setTimeout(() => setMessage(null), 2500);
            }
        } catch (error) {
            setMessage('An error occurred'); // Change this line
            setTimeout(() => setMessage(null), 2500);
        }
    };

    return (
        <body>
            <div className="container mt-5">
                <div className="row justify-content-center">
                    <div className="col-md-6">
                        <div className="card">
                            <div className="card-body">
                                <h1 className="card-title text-center">Reset Password</h1>
                                <form onSubmit={handleSubmit}>
                                    <div className="mb-3">
                                        <label htmlFor="password" className="form-label">
                                            New Password:
                                        </label>
                                        <input 
                                            type="password" 
                                            className="form-control"
                                            value={password} 
                                            onChange={(e) => setPassword(e.target.value)} required />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="confirmPassword" className="form-label">
                                            Confirm Password:
                                        </label>
                                        <input 
                                            type="password" 
                                            className="form-control"
                                            value={confirmPassword} 
                                            onChange={(e) => setConfirmPassword(e.target.value)} required />
                                    </div>
                                    <div className="d-grid gap-2">
                                        <button type="submit" className="btn btn-primary">
                                            Reset Password
                                        </button>
                                    </div>
                                    <div>
                                      <p className="text-center mt-3" style={{ color: message === 'Password reset successful' ? 'green' : 'red' }}>{message}</p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </body>
    );
}

export default ResetPassword;