import React, { useState, useEffect } from 'react';

const UserPortfolio = () => {
  const [portfolioData, setPortfolioData] = useState([]);

  useEffect(() => {
    // Fetch portfolio data from the backend API
    fetch('http://172.21.148.171:8000/api-stocks/stock/', {
      headers: {
        'Authorization': `Token ${sessionStorage.getItem('token')}`
      }
    })
    .then(response => response.json())
    .then(data => setPortfolioData(data)); // Assuming data is an array of objects with stock, quantity, and price properties
  }, []); 

  return (
    <div className="container">
      <div className='card mt-4' style={{border: 'none' }}>     
        <div className='card-body text-center'>
            <h2>My Portfolio</h2>
        </div>
      </div>
      <p/>
      <div className="row">
        <div className="col">
          <h3>Stocks Owned</h3>
          <table className="table">
            <thead>
              <tr>
                <th>Stock</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Current Price</th>
                <th>P/L</th>
                {/* Add more headers if needed */}
              </tr>
            </thead>
            <tbody>
              {portfolioData.map((portfolioItem, index) => (
                <tr key={index}>
                  <td>{portfolioItem.stock}</td>
                  <td>{portfolioItem.quantity}</td>
                  <td>{portfolioItem['Total Price']}</td>
                  <td>{portfolioItem.Close}</td>
                  <td style={{ color: portfolioItem['P/L'] < 0 ? 'red' : 'green' }}>{portfolioItem['P/L']}</td>
                  {/* Add more cells if needed */}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default UserPortfolio;
