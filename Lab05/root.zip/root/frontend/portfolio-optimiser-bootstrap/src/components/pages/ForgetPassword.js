import React, { useState } from 'react';
import axios from 'axios';



function ForgotPassword() {
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');

    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            const response = await axios.post('http://172.21.148.171:8000/api-auth/forget-password/', {
                email: email,
            });

            if (response.status === 200) {
                setMessage('Password reset link has been sent to your email');
                setTimeout(() => setMessage(null), 2500);
            } else {
                setMessage('Failed to send password reset link');
                setTimeout(() => setMessage(null), 2500);
            }
        } catch (error) {
            setMessage('An error occurred');
            setTimeout(() => setMessage(null), 2500);
        }
    };

    return (
    <body>
        <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h1 className="card-title text-center">Reset Password</h1>
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Email:</label>
            
                   <input 
                    type="email"  
                    className='form-control'
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} required />
                    <p></p>
                <div className="d-grid gap-2">
                    <button type=" submit" className='btn btn-primary'>Send Password Reset Link</button>
                    </div>
                    <p className="text-center mt-3" style={{ color: message === 'Password reset link has been sent to your email' ? 'green' : 'red' }}>{message}</p>
        </div>

                </form>
            
        </div>
        </div>
        </div>
        </div>
        </div>

    </body>
    );
}

export default ForgotPassword;