import React, { useState, useEffect } from 'react'
import Listgroup from '../inc/Listgroup';
import Modal from '../inc/Modal'; // Importing Modal component
import stockList from '../inc/Stocklist'; // Importing the stockList array from the stocks.js file

function Stocks() {
    const [showModal, setShowModal] = useState(false);
    const [selectedStock, setSelectedStock] = useState(null);
    const [stockDetails, setStockDetails] = useState(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        // Fetch data from the API when the component mounts
        const fetchData = async () => {
          try {
            if (selectedStock) {
              const response1 = await fetch('http://172.21.148.171:8000/api-stocks/yahoo-web/', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({ ticker: selectedStock.symbol }), // Pass the stock symbol in the request body
              });
              let data1 = await response1.json();
              data1 = { ...data1, name: selectedStock.name, symbol: selectedStock.symbol };

              const response2 = await fetch('http://172.21.148.171:8000/api-stocks/yahoo-chart/', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({ ticker: selectedStock.symbol }),
              });
              let data2 = await response2.json();
              setStockDetails({ ...data1, chartData: data2 });
              console.log(stockDetails);
              setLoading(false);
            }
          } catch (error) {
            console.error('Error fetching data:', error);
          }
        };

        fetchData();
      }, [selectedStock]);

    const handleStockClick = (stock) => {
        // Set selected stock and show the modal
        setSelectedStock(stock);
        setShowModal(true);
        setLoading(true);
      };
  
    const handleCloseModal = () => {
      // Close the modal and reset selected stock
      setShowModal(false);
      setSelectedStock(null);
    };

    return (
      <div
        className="container"
        style={{
          backgroundImage: `url(/stocks_background_image.jpeg)`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          minHeight: '100vh',
          minWidth: '100vW',
          padding: '20px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <div className="card mt-4" style={{ backgroundColor: 'transparent', border: 'none' }}>
          <div className="card-body text-white text-center">
            <h2>The Top-50 Blue Chip Stocks</h2>
          </div>
        </div>
        <div className="my-4">
        <div className="row justify-content-center">
          <div className="col-md-12">
            <div className="row">
              {[...Array(2)].map((_, columnIndex) => (
                <div key={columnIndex} className="col-md-6">
                  <ul className="list-group text-center">
                    {stockList.slice(
                      columnIndex * Math.ceil(stockList.length / 2),
                      (columnIndex + 1) * Math.ceil(stockList.length / 2)
                    ).map((stock) => (
                      <li
                        key={stock.symbol}
                        className="list-group-item btn"
                        onClick={() => handleStockClick(stock)}
                        style={{
                          backgroundColor: '#2874A6',
                          color: '#D6EAF8',
                          border: '1px solid #2874A6',
                          borderRadius: '5px',
                          marginBottom: '10px',
                          transition: 'background-color 0.3s ease', // Add transition for smooth color change on hover
                          boxShadow: '0px 4px 8px rgba(0,0,0, 0.5)', // Add box shadow for a lifted appearance
                        }}
                        onMouseEnter={(e) => {
                          e.target.style.backgroundColor = '#3498DB'; // Change background color on hover
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.backgroundColor = '#2874A6'; // Restore original background color on leave
                        }}
                      >
                        {stock.name} ({stock.symbol})
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
  </div>
  {selectedStock && stockDetails && (
    <Modal show={showModal} onHide={handleCloseModal} stock={stockDetails} chartData={stockDetails.chartData} loading={loading} />
  )}
</div>
      </div>
    );
  
}

export default Stocks;