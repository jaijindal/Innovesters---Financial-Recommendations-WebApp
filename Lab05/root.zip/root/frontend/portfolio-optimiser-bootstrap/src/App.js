import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/inc/Layout'
import Login from './components/pages/Login'
import Register from './components/pages/Register';
import Home from './components/pages/Home'
import UserPortfolio from './components/pages/MyPortfolio'
import Optimise from './components/pages/Optimise'
import Stocks from './components/pages/Stocks'
import TransactionLog from './components/pages/TransactionLog';
import Profile from './components/pages/MyProfile';
import ResetPassword from './components/pages/ResetPassword';
import ForgetPassword from './components/pages/ForgetPassword';
import Playground from './components/pages/Playground'

function App() {
  return (
    <Router>
      <Layout>
      <Routes>
        <Route path={'/register'} element={<Register/>}/>
        <Route path={'/login'} element={<Login/>}/>
        <Route path={'/'} exact element={<Home/>}/>
        <Route path={'/my-portfolio'} element={<UserPortfolio/>}/>
        <Route path={'/optimise'} element={<Optimise/>}/>
        <Route path={'/stocks'} element={<Stocks/>}/>
        <Route path={'/my-transactions'} element={<TransactionLog/>}/>
        <Route path={'/my-profile'} element={<Profile/>}/>
        <Route path={'/reset-password'} element={<ResetPassword/>}/>
        <Route path={'/forget-password'} element={<ForgetPassword/>}/>
        <Route path={'/playground'} element={<Playground/>}/>
      </Routes>
      </Layout>
    </Router>
  );
}

export default App;
